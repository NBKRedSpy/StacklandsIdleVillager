# Stacklands Idle Villager

Creates an animated red border around Villagers that are not placed on a card (not working) or in combat.

![Idle Villager](Thunderstore.io-Package/icon.png)